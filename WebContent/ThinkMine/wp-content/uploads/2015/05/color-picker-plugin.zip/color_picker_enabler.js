<script type="text/javascript">
  jQuery(document).ready(function($){
           $('.color-picker').wpColorPicker();
  });
 </script>