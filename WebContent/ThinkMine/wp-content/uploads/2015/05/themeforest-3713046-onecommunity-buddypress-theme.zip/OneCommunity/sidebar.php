<div id="sidebar">
<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('sidebar-pages')) : ?><?php endif; ?>
</div><!--sidebar ends-->