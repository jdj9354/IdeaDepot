<div style="font:32px Verdana; color:#00ae39; text-align:center; width:800px; margin:0 auto; margin-top:60px; font-weight:bold;">
Create empty page called `Home` (Pages &rarr; Add New) with selected `Frontpage 1`, `Frontpage 2` or `Frontpage 3` page template and setup `Home` page as your frontpage.<br /><br />
More information you will find in the documentation.
</div>