<?php get_header(); ?>

<div id="content">
<div class="page-title"><?php _e('Not Found', 'OneCommunity'); ?>!</div>
<br />

<p><?php _e( "We're sorry, but we can't find the page that you're looking for. Perhaps searching will help.", 'OneCommunity' ); ?></p>

<br /><br />
</div><!-- #content -->

<?php get_footer(); ?>